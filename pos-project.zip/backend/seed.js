const db = require('./db');
const { v4: uuidv4 } = require('uuid');
const run = (sql, params=[]) => db.prepare(sql).run(...params);

const items = [
  ['Green Tea', 120, 50, 'GT-001'],
  ['Notebook A5', 250, 30, 'NB-A5'],
  ['Pen Black', 25, 200, 'PN-BK']
];

for (const [name,price,stock,sku] of items) {
  try {
    run('INSERT INTO products (id,name,price,stock,sku) VALUES (?,?,?,?,?)', [uuidv4(), name, price, stock, sku]);
  } catch(e){ /* ignore duplicates */ }
}

console.log('✅ Sample products ensured.');
