// run: node seed_auth.js
const db = require('./db');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');

(async () => {
  const run = (sql, params=[]) => db.prepare(sql).run(...params);

  const username = 'admin';
  const password = 'password123'; // change after first run!
  const hash = await bcrypt.hash(password, 10);

  try {
    run('INSERT INTO users (id,username,password_hash,role) VALUES (?,?,?,?)', [uuidv4(), username, hash, 'admin']);
    console.log('✅ Admin user created: admin / password123 (change this password!)');
  } catch(e){
    console.log('⚠️ Admin user already exists or error:', e.message);
  }
  process.exit();
})();
