const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const JWT_SECRET = process.env.JWT_SECRET || 'supersecret_jwt_key_change_this';

// Helpers
const run = (sql, params=[]) => db.prepare(sql).run(...params);
const get = (sql, params=[]) => db.prepare(sql).get(...params);
const all = (sql, params=[]) => db.prepare(sql).all(...params);

// Auth middleware
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'Unauthorized' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// --- AUTH endpoints ---
app.post('/api/login', async (req,res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'username and password required' });

  const user = get('SELECT * FROM users WHERE username = ?', [username]);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token, username: user.username, role: user.role });
});

// --- Products (public read) ---
app.get('/api/products', (req, res) => {
  const rows = all('SELECT * FROM products');
  res.json(rows);
});

app.post('/api/products', authMiddleware, (req, res) => {
  // only admin can add products
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const { name, price, stock=0, sku=null } = req.body;
  const id = uuidv4();
  run('INSERT INTO products (id,name,price,stock,sku) VALUES (?,?,?,?,?)', [id,name,price,stock,sku]);
  res.json({ id, name, price, stock, sku });
});

app.put('/api/products/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const id = req.params.id;
  const { name, price, stock, sku } = req.body;
  run('UPDATE products SET name=?,price=?,stock=?,sku=? WHERE id=?', [name,price,stock,sku,id]);
  res.json({ ok: true });
});

app.delete('/api/products/:id', authMiddleware, (req,res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  run('DELETE FROM products WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// --- Checkout (protected) ---
app.post('/api/checkout', authMiddleware, (req,res) => {
  const { items } = req.body;
  if (!items?.length) return res.status(400).json({error:'Cart empty'});

  let total = 0;
  const saleItems = [];

  try {
    const tx = db.transaction(() => {
      for (const it of items) {
        const p = db.prepare('SELECT * FROM products WHERE id=?').get(it.id);
        if (!p) throw new Error('Product not found: ' + it.id);
        if (p.stock < it.qty) throw new Error('Insufficient stock for ' + p.name);
        total += p.price * it.qty;
        saleItems.push({ id:p.id, name:p.name, price:p.price, qty:it.qty });
        run('UPDATE products SET stock=stock-? WHERE id=?', [it.qty, it.id]);
      }
      const saleId = uuidv4();
      const created = new Date().toISOString();
      run('INSERT INTO sales (id,created_at,total,items_json) VALUES (?,?,?,?)', [saleId, created, total, JSON.stringify(saleItems)]);
      return { id:saleId, created, total, items:saleItems };
    });
    const sale = tx();
    res.json({ ok:true, sale });
  } catch(e){
    res.status(400).json({error:e.message});
  }
});

// --- Sales list (protected) ---
app.get('/api/sales', authMiddleware, (req,res)=>{
  const rows = all('SELECT * FROM sales ORDER BY created_at DESC LIMIT 200');
  for(const r of rows) r.items = JSON.parse(r.items_json);
  res.json(rows);
});

// --- Printable receipt endpoint (protected) ---
app.get('/api/receipt/:id', authMiddleware, (req,res) => {
  const id = req.params.id;
  const sale = get('SELECT * FROM sales WHERE id=?', [id]);
  if (!sale) return res.status(404).send('Sale not found');

  const items = JSON.parse(sale.items_json);
  const html = `
  <!doctype html>
  <html>
  <head>
    <meta charset="utf-8" />
    <title>Receipt - ${sale.id}</title>
    <style>
      body{font-family:Arial;padding:20px;}
      .header{text-align:center;}
      .items{width:100%;border-collapse:collapse;margin-top:20px;}
      .items th,.items td{border-bottom:1px solid #ddd;padding:8px;text-align:left;}
      .total{margin-top:12px;font-weight:bold;}
      @media print { button { display:none; } }
    </style>
  </head>
  <body>
    <div class="header">
      <h2>Shop Name</h2>
      <div>Receipt: ${sale.id}</div>
      <div>${new Date(sale.created_at).toLocaleString()}</div>
    </div>
    <table class="items">
      <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Sub</th></tr></thead>
      <tbody>
        ${items.map(it => `<tr><td>${it.name}</td><td>${it.qty}</td><td>Rs ${it.price.toFixed(2)}</td><td>Rs ${(it.qty*it.price).toFixed(2)}</td></tr>`).join('')}
      </tbody>
    </table>
    <div class="total">Total: Rs ${sale.total.toFixed(2)}</div>
    <div style="margin-top:20px;">
      <button onclick="window.print()">Print</button>
      <button onclick="window.close()">Close</button>
    </div>
  </body>
  </html>
  `;
  res.send(html);
});

// --- Daily report (protected). query param date=YYYY-MM-DD optional (default today) ---
app.get('/api/report/daily', authMiddleware, (req,res) => {
  const qdate = req.query.date || new Date().toISOString().slice(0,10);
  const rows = all("SELECT * FROM sales WHERE created_at LIKE ? ", [qdate + '%']);
  const total = rows.reduce((s,r)=>s + r.total, 0);
  const productTotals = {};
  for(const r of rows){
    const items = JSON.parse(r.items_json);
    for(const it of items){
      if (!productTotals[it.name]) productTotals[it.name] = { qty:0, revenue:0 };
      productTotals[it.name].qty += it.qty;
      productTotals[it.name].revenue += it.qty * it.price;
    }
  }
  res.json({ date: qdate, total, count: rows.length, productTotals });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log(`✅ POS backend running at http://localhost:${PORT}`));
