import React, {useEffect, useState} from 'react'
import Login from './components/Login'
import ProductList from './components/ProductList'
import Cart from './components/Cart'
import Checkout from './components/Checkout'
import SalesReport from './components/SalesReport'

const API = 'http://localhost:4000/api'

export default function App(){
  const [products,setProducts] = useState([])
  const [cart,setCart] = useState([])
  const [token,setToken] = useState(localStorage.getItem('token') || null)
  const [user,setUser] = useState(null)

  useEffect(()=>{ fetchProducts() },[token])

  async function fetchProducts(){
    try {
      const res = await fetch(API + '/products')
      const data = await res.json()
      setProducts(data)
    } catch(e){ console.error(e) }
  }

  function addToCart(p){
    setCart(prev=>{
      const e = prev.find(x=>x.id===p.id)
      if(e) return prev.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x)
      return [...prev,{...p,qty:1}]
    })
  }

  function updateQty(id,qty){
    setCart(prev=>prev.map(x=>x.id===id?{...x,qty}:x).filter(x=>x.qty>0))
  }

  function onLogin(token, username){
    setToken(token)
    localStorage.setItem('token', token)
    setUser({ username })
  }

  function logout(){
    setToken(null)
    localStorage.removeItem('token')
    setUser(null)
  }

  async function checkoutComplete(){
    setCart([])
    fetchProducts()
  }

  return (
    <div className="container">
      <h1>🧾 Simple POS</h1>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
        <div>{user ? `Logged in: ${user.username}` : 'Not logged in'}</div>
        <div>
          {user ? <button onClick={logout}>Logout</button> : null}
        </div>
      </div>

      {!token ? (
        <Login onLogin={onLogin} />
      ) : (
        <div className="main">
          <div className="left-col">
            <ProductList products={products} onAdd={addToCart} />
          </div>
          <div className="right-col">
            <Cart cart={cart} updateQty={updateQty} />
            <Checkout cart={cart} token={token} onSuccess={checkoutComplete} />
            <SalesReport token={token} />
          </div>
        </div>
      )}
    </div>
  )
}
