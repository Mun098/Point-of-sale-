import React from 'react'

export default function Cart({cart, updateQty}){
  const total = cart.reduce((s,i)=>s + i.price*i.qty,0)
  return (
    <div className="cart">
      <h3>Cart</h3>
      {cart.length===0 && <div>Cart is empty</div>}
      {cart.map(i=>(
        <div key={i.id} className="cart-item">
          <div>{i.name} x {i.qty}</div>
          <div>
            <button onClick={()=>updateQty(i.id, i.qty-1)}>-</button>
            <button onClick={()=>updateQty(i.id, i.qty+1)} style={{marginLeft:6}}>+</button>
          </div>
        </div>
      ))}
      <h3 style={{marginTop:12}}>Total: Rs {total.toFixed(2)}</h3>
    </div>
  )
}
