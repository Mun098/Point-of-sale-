import React, {useState} from 'react'
const API = 'http://localhost:4000/api'

export default function Checkout({cart, onSuccess, token}){
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  async function handleCheckout(){
    if (!cart.length) return setMessage('Cart empty')
    setLoading(true)
    const items = cart.map(i=> ({ id: i.id, qty: i.qty }))
    try {
      const res = await fetch(API + '/checkout', {
        method: 'POST',
        headers: {'Content-Type':'application/json', 'Authorization': 'Bearer ' + token},
        body: JSON.stringify({items})
      });
      const data = await res.json()
      if (data.ok){
        setMessage('Sale recorded. Total: Rs ' + data.sale.total.toFixed(2))
        onSuccess()
        // open printable receipt in new window:
        const url = `${API.replace('/api','')}/api/receipt/${data.sale.id}`
        window.open(url, '_blank')
      } else {
        setMessage('Error: ' + (data.error || 'Unknown'))
      }
    } catch(err){
      setMessage('Network error: ' + err.message)
    } finally { setLoading(false) }
  }

  return (
    <div style={{marginTop:12}}>
      <button onClick={handleCheckout} disabled={loading}>Checkout</button>
      <div style={{marginTop:8}}>{message}</div>
    </div>
  )
}
