import React, {useState} from 'react'
const API = 'http://localhost:4000/api'

export default function Login({onLogin}){
  const [username,setUsername] = useState('')
  const [password,setPassword] = useState('')
  const [msg,setMsg] = useState('')

  async function handleLogin(e){
    e.preventDefault()
    setMsg('Logging in...')
    try {
      const res = await fetch(API + '/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})})
      const data = await res.json()
      if (data.token){
        onLogin(data.token, data.username)
      } else {
        setMsg(data.error || 'Login failed')
      }
    } catch(e){
      setMsg('Network error')
    }
  }

  return (
    <div style={{maxWidth:420, margin:'20px auto', background:'#fff', padding:20, borderRadius:8}}>
      <h3>Login</h3>
      <form onSubmit={handleLogin}>
        <div style={{marginTop:8}}>
          <input placeholder="username" value={username} onChange={e=>setUsername(e.target.value)} />
        </div>
        <div style={{marginTop:8}}>
          <input type="password" placeholder="password" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <div style={{marginTop:12}}>
          <button type="submit">Login</button>
        </div>
      </form>
      <div style={{color:'red', marginTop:10}}>{msg}</div>
    </div>
  )
}
