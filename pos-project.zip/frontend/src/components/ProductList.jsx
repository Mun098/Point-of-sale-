import React from 'react'

export default function ProductList({products, onAdd}){
  return (
    <div className="products">
      <h2>Products</h2>
      <div>
        {products.map(p=>(
          <div key={p.id} className="product">
            <div>
              <strong>{p.name}</strong><br />
              Rs {Number(p.price).toFixed(2)} | Stock: {p.stock}
            </div>
            <div>
              <button disabled={p.stock<=0} onClick={()=>onAdd(p)}>Add</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
