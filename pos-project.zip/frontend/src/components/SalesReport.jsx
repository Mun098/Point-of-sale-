import React, {useState} from 'react'
const API = 'http://localhost:4000/api'

export default function SalesReport({token}) {
  const [date, setDate] = useState(new Date().toISOString().slice(0,10))
  const [report, setReport] = useState(null)
  const [msg, setMsg] = useState('')

  async function fetchReport(){
    setMsg('Loading...')
    try {
      const res = await fetch(`${API}/report/daily?date=${date}`, { headers: { 'Authorization': 'Bearer ' + token } })
      if (res.status === 401) return setMsg('Unauthorized. Login again.')
      const data = await res.json()
      setReport(data)
      setMsg('')
    } catch(e){
      setMsg('Network error')
    }
  }

  return (
    <div style={{background:'#fff', padding:12, borderRadius:8, marginTop:12}}>
      <h3>Daily Sales Report</h3>
      <div style={{display:'flex', gap:8, alignItems:'center'}}>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} />
        <button onClick={fetchReport}>Get Report</button>
      </div>
      {msg && <div style={{marginTop:8}}>{msg}</div>}
      {report && (
        <div style={{marginTop:12}}>
          <div><b>Date:</b> {report.date}</div>
          <div><b>Total Sales:</b> Rs {report.total.toFixed(2)} ({report.count} transactions)</div>
          <h4>By Product</h4>
          <table style={{width:'100%'}}>
            <tbody>
              {Object.keys(report.productTotals).length === 0 && <tr><td>No sales</td></tr>}
              {Object.keys(report.productTotals).map(name => (
                <tr key={name}>
                  <td>{name}</td>
                  <td>Qty: {report.productTotals[name].qty}</td>
                  <td>Revenue: Rs {report.productTotals[name].revenue.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
